package org.portfolioservice;

public class PrintReportService {
    public PrintReportService(IPriceProxyPort priceProxyPort, IPrinterPort printerPort) {

    }
}
