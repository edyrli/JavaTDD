package org.portfolioservice;

public interface IPrinterPort {
    void Print(String report);
}
