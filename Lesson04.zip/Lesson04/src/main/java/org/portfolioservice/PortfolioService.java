package org.portfolioservice;

public class PortfolioService {

    public PortfolioService(ICalendarPort calendarPort, PrintReportService printReportService, ITransactionRepositoryPort transactionRepositoryPort) {


    }
}
