package org.portfolioservice;

public interface IPriceProxyPort {
}
