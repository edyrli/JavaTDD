package org.portfolioservice;

public interface ITransactionRepositoryPort {
}
