package org.portfolioservice;

public interface ICalendarPort {
}
