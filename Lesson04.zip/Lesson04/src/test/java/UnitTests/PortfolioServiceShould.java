package UnitTests;

import org.junit.jupiter.api.Test;

public class PortfolioServiceShould {
    @Test
    public void PrintHeaderWhenThereAreNoTransactions(){

    }
}
