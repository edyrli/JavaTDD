package AcceptanceTests;

import org.portfolioservice.ITransactionRepositoryPort;

public class TransactionRepositoryFake implements ITransactionRepositoryPort {
}
